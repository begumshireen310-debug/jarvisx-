package com.jarvisx.app.data

import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray

/** Long-term memory: only things the user explicitly asked to remember. Encrypted on this phone. */
class MemoryStore(private val store: ApiKeyStore) {
    val items = mutableStateListOf<String>()

    init {
        try {
            val a = JSONArray(store.getString("memories").ifEmpty { "[]" })
            for (i in 0 until a.length()) items.add(a.getString(i))
        } catch (e: Exception) {
            // start empty
        }
    }

    /** Returns true only if it was really saved to storage. */
    fun add(text: String): Boolean {
        items.add(text.trim())
        return save()
    }

    fun clear(): Boolean {
        items.clear()
        return save()
    }

    private fun save(): Boolean {
        val a = JSONArray()
        items.forEach { a.put(it) }
        return store.putString("memories", a.toString())
    }
}
