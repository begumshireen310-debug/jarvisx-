package com.jarvisx.app.data

import android.content.Context
import com.jarvisx.app.ui.ThemeMode

/** Simple persistent settings (SharedPreferences). No secrets are stored here. */
class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("jarvis_settings", Context.MODE_PRIVATE)

    var theme: ThemeMode
        get() = runCatching { ThemeMode.valueOf(prefs.getString("theme", "DARK") ?: "DARK") }
            .getOrDefault(ThemeMode.DARK)
        set(v) { prefs.edit().putString("theme", v.name).apply() }

    var pitch: Float
        get() = prefs.getFloat("pitch", 0.6f)
        set(v) { prefs.edit().putFloat("pitch", v).apply() }

    var speed: Float
        get() = prefs.getFloat("speed", 0.9f)
        set(v) { prefs.edit().putFloat("speed", v).apply() }

    var language: String
        get() = prefs.getString("language", "hi-IN") ?: "hi-IN"
        set(v) { prefs.edit().putString("language", v).apply() }

    var userName: String
        get() = prefs.getString("userName", "SULEMAN") ?: "SULEMAN"
        set(v) { prefs.edit().putString("userName", v).apply() }

    fun clearAll() { prefs.edit().clear().apply() }
}
