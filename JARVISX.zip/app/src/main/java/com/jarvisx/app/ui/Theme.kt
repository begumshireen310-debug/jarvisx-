package com.jarvisx.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

enum class ThemeMode(val label: String) {
    SUNSET("Sunset"), DARK("Dark"), LIGHT("Light")
}

enum class AssistantState(val label: String) {
    STANDBY("STANDBY"), LISTENING("LISTENING"), PROCESSING("PROCESSING"), SPEAKING("SPEAKING")
}

data class JarvisPalette(
    val bgTop: Color,
    val bgBottom: Color,
    val accent: Color,
    val accent2: Color,
    val text: Color,
    val subText: Color,
    val isDark: Boolean
)

fun paletteFor(mode: ThemeMode): JarvisPalette = when (mode) {
    ThemeMode.SUNSET -> JarvisPalette(
        Color(0xFF12062B), Color(0xFF4A1942), Color(0xFFFF7A18), Color(0xFFFFC857),
        Color.White, Color(0xFFD7C4E8), true
    )
    ThemeMode.DARK -> JarvisPalette(
        Color(0xFF05080F), Color(0xFF0B1A2A), Color(0xFF00E5FF), Color(0xFFFF1744),
        Color.White, Color(0xFF9FB3C8), true
    )
    ThemeMode.LIGHT -> JarvisPalette(
        Color(0xFFF5F7FA), Color(0xFFDDE6F0), Color(0xFF0077C8), Color(0xFFFF6B00),
        Color(0xFF101820), Color(0xFF4A5A6A), false
    )
}

@Composable
fun JarvisTheme(p: JarvisPalette, content: @Composable () -> Unit) {
    val scheme = if (p.isDark) {
        darkColorScheme(primary = p.accent, background = p.bgTop, surface = p.bgBottom)
    } else {
        lightColorScheme(primary = p.accent, background = p.bgTop, surface = p.bgBottom)
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
