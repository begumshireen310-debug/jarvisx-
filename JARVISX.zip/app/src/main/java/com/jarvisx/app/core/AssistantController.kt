package com.jarvisx.app.core

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.jarvisx.app.ai.GeminiClient
import com.jarvisx.app.data.ApiKeyStore
import com.jarvisx.app.data.ChatLog
import com.jarvisx.app.data.MemoryStore
import com.jarvisx.app.data.SettingsStore
import com.jarvisx.app.ui.AssistantState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AssistantController(
    private val ctx: Context,
    private val store: SettingsStore,
    private val keyStore: ApiKeyStore,
    private val memory: MemoryStore,
    private val chatLog: ChatLog
) {
    var state by mutableStateOf(AssistantState.STANDBY)
        private set
    var heard by mutableStateOf("")
        private set
    var reply by mutableStateOf("Mic dabao aur bolo.")
        private set

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val actions = PhoneActions(ctx)
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    init {
        tts = TextToSpeech(ctx.applicationContext) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        main.post { if (state == AssistantState.SPEAKING) state = AssistantState.STANDBY }
                    }
                    override fun onError(utteranceId: String?) {
                        main.post { if (state == AssistantState.SPEAKING) state = AssistantState.STANDBY }
                    }
                })
            }
        }
    }

    private fun isHindi(): Boolean = store.language.startsWith("hi")
    private fun m(hi: String, en: String): String = if (isHindi()) hi else en

    fun showMessage(text: String) {
        reply = text
    }

    /** Mic button: start listening; while listening = finish early; while speaking = interrupt and listen. */
    fun onMicPressed() {
        when (state) {
            AssistantState.STANDBY -> beginListening()
            AssistantState.LISTENING -> recognizer?.stopListening()
            AssistantState.SPEAKING -> {
                tts?.stop()
                beginListening()
            }
            AssistantState.PROCESSING -> {}
        }
    }

    private fun beginListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            reply = "Is phone mein speech recognition nahi mila. Google app enable / update karo."
            state = AssistantState.STANDBY
            return
        }
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onPartialResults(partialResults: Bundle?) {
                val p = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!p.isNullOrBlank()) heard = p
            }

            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (text.isNullOrBlank()) {
                    reply = "Kuch sunai nahi diya. Dobara try karo."
                    state = AssistantState.STANDBY
                } else {
                    handle(text)
                }
            }

            override fun onError(error: Int) {
                reply = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                        "Kuch sunai nahi diya. Mic dabake dobara bolo."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                        "Mic permission do (phone Settings > Apps > JARVIS X > Permissions)."
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER ->
                        "Speech service ko internet chahiye. Net check karo."
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognizer busy hai. Thodi der baad try karo."
                    else -> "Speech error (code $error)."
                }
                state = AssistantState.STANDBY
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, store.language)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        heard = ""
        state = AssistantState.LISTENING
        r.startListening(i)
    }

    private fun handle(text: String) {
        state = AssistantState.PROCESSING
        heard = text
        val cmd = CommandRouter.parse(text)
        if (cmd is Command.Unknown) {
            askAi(text)
            return
        }
        val result = execute(cmd)
        chatLog.add("user", text)
        chatLog.add("model", result)
        speak(result)
    }

    private fun systemPrompt(): String {
        val base = "You are JARVIS, a smart, polite personal voice assistant like in the Iron Man movies. " +
            "Your answer is spoken aloud, so reply in 1 to 3 short sentences. No markdown, no emojis, no lists. " +
            "Reply in the same language the user used: Hindi in Devanagari script if they spoke Hindi, otherwise English. " +
            "You cannot control the phone yourself; never claim you performed a phone action."
        return if (memory.items.isEmpty()) base
        else base + " Things the user asked you to remember: " + memory.items.joinToString("; ")
    }

    private fun askAi(text: String) {
        val key = keyStore.load()
        if (key.isEmpty()) {
            val msg = m(
                "ये समझ नहीं आया. AI से बात करने के लिए Settings में Gemini key डालो.",
                "I didn't get that. Add your Gemini key in Settings to chat with AI."
            )
            chatLog.add("user", text)
            chatLog.add("model", msg)
            speak(msg)
            return
        }
        chatLog.add("user", text)
        state = AssistantState.PROCESSING
        scope.launch {
            val ctxMsgs = chatLog.items.takeLast(12).dropWhile { it.role != "user" }.toList()
            val r = GeminiClient.chat(key, systemPrompt(), ctxMsgs)
            if (r.ok) {
                chatLog.add("model", r.message)
                speak(r.message)
            } else {
                chatLog.removeLast()
                reply = r.message
                state = AssistantState.STANDBY
            }
        }
    }

    private fun execute(cmd: Command): String {
        return when (cmd) {
            is Command.OpenApp -> {
                val n = cmd.app.display
                when (actions.openApp(cmd.app)) {
                    PhoneActions.Outcome.OK -> m("$n खोल रहा हूँ.", "Opening $n.")
                    PhoneActions.Outcome.NOT_INSTALLED -> m(
                        "$n इस फ़ोन में नहीं मिला. Play Store से इंस्टॉल करो.",
                        "$n is not installed. Please install it from the Play Store."
                    )
                    PhoneActions.Outcome.FAILED -> m("$n नहीं खुल पाया.", "Couldn't open $n.")
                }
            }
            is Command.YouTubeSearch -> when (actions.youtubeSearch(cmd.query)) {
                PhoneActions.Outcome.OK -> m(
                    "YouTube पर ${cmd.query} सर्च कर रहा हूँ.", "Searching YouTube for ${cmd.query}."
                )
                else -> m("YouTube नहीं खुल पाया.", "Couldn't open YouTube.")
            }
            is Command.YouTubePlay -> when (actions.youtubeSearch(cmd.query)) {
                PhoneActions.Outcome.OK -> m(
                    "YouTube पर ${cmd.query} के नतीजे खोल दिए. सीधा चलाना अभी सपोर्ट नहीं है, वीडियो खुद चुनकर दबाओ.",
                    "Opened YouTube results for ${cmd.query}. Direct playback isn't supported yet; please tap a video."
                )
                else -> m("YouTube नहीं खुल पाया.", "Couldn't open YouTube.")
            }
            is Command.WebSearch -> when (actions.webSearch(cmd.query)) {
                PhoneActions.Outcome.OK -> m(
                    "${cmd.query} सर्च कर रहा हूँ.", "Searching the web for ${cmd.query}."
                )
                else -> m("सर्च नहीं खुल पाया.", "Couldn't open the search.")
            }
            is Command.OpenWebsite -> when (actions.openWebsite(cmd.url)) {
                PhoneActions.Outcome.OK -> m("${cmd.url} खोल रहा हूँ.", "Opening ${cmd.url}.")
                else -> m("वेबसाइट नहीं खुल पाई.", "Couldn't open the website.")
            }
            is Command.Flashlight -> when (actions.flashlight(cmd.on)) {
                PhoneActions.Outcome.OK ->
                    if (cmd.on) m("टॉर्च चालू कर दी.", "Flashlight on.") else m("टॉर्च बंद कर दी.", "Flashlight off.")
                else -> m("टॉर्च नहीं चल पाई.", "Couldn't control the flashlight.")
            }
            is Command.Volume -> when (actions.volume(cmd.action)) {
                PhoneActions.Outcome.OK -> when (cmd.action) {
                    VolumeAction.UP -> m("वॉल्यूम बढ़ा दिया.", "Volume up.")
                    VolumeAction.DOWN -> m("वॉल्यूम कम कर दिया.", "Volume down.")
                    VolumeAction.MUTE -> m("म्यूट कर दिया.", "Muted.")
                }
                else -> m("वॉल्यूम नहीं बदल पाया.", "Couldn't change the volume.")
            }
            Command.GoHome -> when (actions.goHome()) {
                PhoneActions.Outcome.OK -> m("होम स्क्रीन पर जा रहा हूँ.", "Going to the home screen.")
                else -> m("होम पर नहीं जा पाया.", "Couldn't go home.")
            }
            Command.Time -> {
                val t = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
                m("अभी समय $t है.", "The time is $t.")
            }
            Command.Date -> {
                val d = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date())
                m("आज $d है.", "Today is $d.")
            }
            Command.Unsupported -> m(
                "पॉज़, नेक्स्ट जैसे मीडिया कंट्रोल अभी सपोर्ट नहीं हैं.",
                "Media controls like pause and next aren't supported yet."
            )
            is Command.Remember -> {
                if (memory.add(cmd.text)) {
                    m("ठीक है, याद रख लिया.", "Okay, I'll remember that.")
                } else {
                    m("मैं इसे हमेशा के लिए सेव नहीं कर पाया, सिर्फ अभी के लिए याद है.",
                        "I couldn't save that permanently; I only have it for now.")
                }
            }
            Command.ForgetAll -> {
                if (memory.clear()) m("सब भूल गया.", "Memory cleared.")
                else m("मेमोरी पूरी तरह साफ़ नहीं हो पाई.", "I couldn't fully clear the memory.")
            }
            is Command.Unclear -> if (cmd.what == "volume") {
                m("वॉल्यूम बढ़ाना है या कम करना है?", "Do you want the volume up or down?")
            } else {
                m("कौन सा ऐप खोलूँ?", "Which app should I open?")
            }
            is Command.Unknown -> ""
        }
    }

    private fun speak(raw: String) {
        val text = raw.replace("*", "").replace("#", "")
        reply = text
        val t = tts
        if (!ttsReady || t == null) {
            state = AssistantState.STANDBY
            return
        }
        val r = t.setLanguage(Locale.forLanguageTag(store.language))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            t.setLanguage(Locale.forLanguageTag("en-IN"))
            reply = text + "\n(Is bhasha ki voice phone mein nahi hai. Phone Settings > Text-to-speech mein install karo.)"
        }
        t.setPitch(store.pitch)
        t.setSpeechRate(store.speed)
        state = AssistantState.SPEAKING
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jx")
    }

    fun shutdown() {
        scope.cancel()
        recognizer?.destroy()
        recognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
