package com.jarvisx.app.core

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import com.jarvisx.app.MayaAccessibilityService
import com.jarvisx.app.ai.GeminiClient
import com.jarvisx.app.data.ApiKeyStore
import com.jarvisx.app.data.ChatLog
import com.jarvisx.app.data.MemoryStore
import com.jarvisx.app.data.SettingsStore
import com.jarvisx.app.ui.AssistantState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AssistantController(
    private val ctx: Context,
    val store: SettingsStore,
    val keyStore: ApiKeyStore,
    val memory: MemoryStore,
    val chatLog: ChatLog
) {
    var state by mutableStateOf(AssistantState.STANDBY)
        private set
    var heard by mutableStateOf("")
        private set
    var reply by mutableStateOf("Tap the core and speak, or turn on BG for background listening.")
        private set
    var continuous by mutableStateOf(false)
        private set
    var needContacts by mutableStateOf(false)
        private set

    private var pendingContact: String? = null
    private var awakeUntil = 0L
    private val wakeRegex = Regex("maya|maia|माया|मया|jarvis|जार्विस", RegexOption.IGNORE_CASE)

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val actions = PhoneActions(ctx)
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    private val restartRunnable = Runnable {
        if (continuous && (state == AssistantState.STANDBY || state == AssistantState.LISTENING)) beginListening()
    }

    init {
        tts = TextToSpeech(ctx.applicationContext) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        main.post { afterSpeaking() }
                    }
                    override fun onError(utteranceId: String?) {
                        main.post { afterSpeaking() }
                    }
                })
            }
        }
    }

    private fun afterSpeaking() {
        if (state == AssistantState.SPEAKING) state = AssistantState.STANDBY
        if (continuous) {
            awakeUntil = System.currentTimeMillis() + 10_000
            scheduleRestart(600)
        }
    }

    private fun scheduleRestart(delayMs: Long) {
        main.removeCallbacks(restartRunnable)
        if (continuous) main.postDelayed(restartRunnable, delayMs)
    }

    private fun isHindi(): Boolean = store.language.startsWith("hi")
    private fun m(hi: String, en: String): String = if (isHindi()) hi else en

    fun showMessage(text: String) {
        reply = text
    }

    fun startContinuous() {
        continuous = true
        awakeUntil = 0L
        if (state == AssistantState.STANDBY) beginListening()
    }

    fun stopContinuous() {
        continuous = false
        main.removeCallbacks(restartRunnable)
        try { recognizer?.cancel() } catch (e: Exception) { }
        if (state == AssistantState.LISTENING) state = AssistantState.STANDBY
    }

    fun hush() {
        tts?.stop()
        if (state == AssistantState.SPEAKING) state = AssistantState.STANDBY
        scheduleRestart(500)
    }

    fun clearNeedContacts() {
        needContacts = false
    }

    fun retryPendingContact() {
        val n = pendingContact ?: return
        pendingContact = null
        speak(whatsappChat(n))
    }

    private fun whatsappChat(name: String): String {
        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) ==
            PackageManager.PERMISSION_GRANTED
        if (!granted) {
            pendingContact = name
            needContacts = true
            return m("कॉन्टैक्ट्स की इजाज़त चाहिए. इजाज़त दे दो.", "I need contacts permission. Please allow it.")
        }
        val number = actions.findContactNumber(name)
            ?: return m("$name नाम का कॉन्टैक्ट नहीं मिला.", "I couldn't find a contact named $name.")
        return when (actions.openWhatsAppChat(number)) {
            PhoneActions.Outcome.OK -> m(
                "$name की WhatsApp चैट खोल रही हूँ. मैसेज खुद लिखकर भेजो.",
                "Opening the WhatsApp chat with $name. Please type and send the message yourself."
            )
            PhoneActions.Outcome.NOT_INSTALLED -> m("WhatsApp इंस्टॉल नहीं है.", "WhatsApp isn't installed.")
            PhoneActions.Outcome.FAILED -> m("WhatsApp चैट नहीं खुल पाई.", "Couldn't open the WhatsApp chat.")
        }
    }

    /** Core tap: start listening; while listening = finish early; while speaking = interrupt and listen. */
    fun onMicPressed() {
        when (state) {
            AssistantState.STANDBY -> beginListening()
            AssistantState.LISTENING -> recognizer?.stopListening()
            AssistantState.SPEAKING -> {
                tts?.stop()
                beginListening()
            }
            AssistantState.PROCESSING -> {}
        }
    }

    private fun beginListening() {
        main.removeCallbacks(restartRunnable)
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            reply = "Is phone mein speech recognition nahi mila. Google app enable / update karo."
            state = AssistantState.STANDBY
            return
        }
        try { recognizer?.destroy() } catch (e: Exception) { }
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onPartialResults(partialResults: Bundle?) {
                val p = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!p.isNullOrBlank() && !continuous) heard = p
            }

            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (text.isNullOrBlank()) {
                    state = AssistantState.STANDBY
                    if (continuous) scheduleRestart(300) else reply = "Kuch sunai nahi diya. Dobara try karo."
                } else {
                    handle(text)
                }
            }

            override fun onError(error: Int) {
                state = AssistantState.STANDBY
                when (error) {
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                        continuous = false
                        reply = "Mic permission do (phone Settings > Apps > Maya > Permissions)."
                    }
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                        if (continuous) scheduleRestart(400) else reply = "Kuch sunai nahi diya. Mic dabake dobara bolo."
                    }
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                        if (continuous) scheduleRestart(1500) else reply = "Recognizer busy hai. Thodi der baad try karo."
                    }
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER -> {
                        reply = "Speech service ko internet chahiye. Net check karo."
                        if (continuous) scheduleRestart(4000)
                    }
                    else -> {
                        if (continuous) scheduleRestart(1000) else reply = "Speech error (code $error)."
                    }
                }
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, store.language)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        if (!continuous) heard = ""
        state = AssistantState.LISTENING
        r.startListening(i)
    }

    private fun handle(text: String) {
        val hasWake = wakeRegex.containsMatchIn(text)
        if (continuous && !hasWake && System.currentTimeMillis() > awakeUntil) {
            state = AssistantState.STANDBY
            scheduleRestart(300)
            return
        }
        state = AssistantState.PROCESSING
        heard = text
        val cleaned = CommandRouter.stripWake(text)
        if (cleaned.isBlank()) {
            speak(m("जी?", "Yes?"))
            return
        }
        val cmd = CommandRouter.parse(text)
        if (cmd is Command.Unknown) {
            askAi(cleaned)
            return
        }
        val result = execute(cmd)
        chatLog.add("user", cleaned)
        chatLog.add("model", result)
        speak(result)
    }

    private fun needA11y(): String = m(
        "स्क्रीन कंट्रोल के लिए Settings में Screen control (Accessibility) चालू करो.",
        "Turn on Screen control (Accessibility) in Settings first."
    )

    private fun retryPlay(left: Int) {
        val svc = MayaAccessibilityService.instance ?: return
        val r = svc.playFirstYouTubeResult()
        if (r == MayaAccessibilityService.PlayResult.NOT_READY && left > 1) {
            main.postDelayed({ retryPlay(left - 1) }, 2000)
        }
    }

    private fun systemPrompt(): String {
        val base = "You are JARVIS, a smart, polite, calm personal voice assistant. " +
            "Your answer is spoken aloud, so reply in 1 to 3 short sentences. No markdown, no emojis, no lists. " +
            "Reply in the same language the user used: Hindi in Devanagari script if they spoke Hindi, otherwise English. " +
            "You cannot control the phone yourself; never claim you performed a phone action."
        return if (memory.items.isEmpty()) base
        else base + " Things the user asked you to remember: " + memory.items.joinToString("; ")
    }

    private fun askAi(text: String) {
        val key = keyStore.load()
        if (key.isEmpty()) {
            val msg = m(
                "ये समझ नहीं आया. AI से बात करने के लिए Settings में Gemini key डालो.",
                "I didn't get that. Add your Gemini key in Settings to chat with AI."
            )
            chatLog.add("user", text)
            chatLog.add("model", msg)
            speak(msg)
            return
        }
        chatLog.add("user", text)
        state = AssistantState.PROCESSING
        scope.launch {
            val ctxMsgs = chatLog.items.takeLast(12).dropWhile { it.role != "user" }.toList()
            val r = GeminiClient.chat(key, systemPrompt(), ctxMsgs)
            if (r.ok) {
                chatLog.add("model", r.message)
                speak(r.message)
            } else {
                chatLog.removeLast()
                reply = r.message
                state = AssistantState.STANDBY
                scheduleRestart(1500)
            }
        }
    }

    private fun execute(cmd: Command): String {
        return when (cmd) {
            is Command.OpenApp -> {
                val n = cmd.app.display
                when (actions.openApp(cmd.app)) {
                    PhoneActions.Outcome.OK -> m("$n खोल रही हूँ.", "Opening $n.")
                    PhoneActions.Outcome.NOT_INSTALLED -> m(
                        "$n इस फ़ोन में नहीं मिला. Play Store से इंस्टॉल करो.",
                        "$n is not installed. Please install it from the Play Store."
                    )
                    PhoneActions.Outcome.FAILED -> m("$n नहीं खुल पाया.", "Couldn't open $n.")
                }
            }
            is Command.YouTubeSearch -> when (actions.youtubeSearch(cmd.query)) {
                PhoneActions.Outcome.OK -> m(
                    "YouTube पर ${cmd.query} सर्च कर रही हूँ.", "Searching YouTube for ${cmd.query}."
                )
                else -> m("YouTube नहीं खुल पाया.", "Couldn't open YouTube.")
            }
            is Command.YouTubePlay -> when (actions.youtubeSearch(cmd.query)) {
                PhoneActions.Outcome.OK -> {
                    if (MayaAccessibilityService.instance != null) {
                        main.postDelayed({ retryPlay(4) }, 3500)
                        m(
                            "YouTube पर ${cmd.query} खोला, पहला वीडियो दबाने की कोशिश कर रही हूँ.",
                            "Opened YouTube for ${cmd.query}; trying to tap the first video."
                        )
                    } else {
                        m(
                            "YouTube पर ${cmd.query} के नतीजे खोल दिए. वीडियो अपने आप चलाने के लिए Settings में Screen control चालू करो.",
                            "Opened YouTube results for ${cmd.query}. To auto-play, turn on Screen control in Settings."
                        )
                    }
                }
                else -> m("YouTube नहीं खुल पाया.", "Couldn't open YouTube.")
            }
            is Command.Screen -> {
                val svc = MayaAccessibilityService.instance
                if (svc == null) needA11y()
                else if (svc.doAction(cmd.action)) m("ठीक है.", "Done.")
                else m("ये नहीं हो पाया.", "I couldn't do that.")
            }
            is Command.YouTubeComment -> {
                val svc = MayaAccessibilityService.instance
                if (svc == null) needA11y()
                else if (svc.postYouTubeComment(cmd.text)) m(
                    "कमेंट लिखने की कोशिश कर रही हूँ. YouTube में लॉगिन होना चाहिए और वीडियो खुला होना चाहिए. मैं पक्का नहीं बता सकती कि कमेंट पोस्ट हुआ या नहीं.",
                    "Trying to post your comment. You must be signed in to YouTube with a video open. I can't confirm it was posted."
                )
                else m("पहले YouTube में कोई वीडियो खोलो.", "Open a YouTube video first.")
            }
            is Command.ClickText -> {
                val svc = MayaAccessibilityService.instance
                if (svc == null) needA11y()
                else if (svc.clickText(cmd.text)) m("दबा दिया.", "Tapped it.")
                else m("${cmd.text} नाम का बटन नहीं मिला.", "I couldn't find a button called ${cmd.text}.")
            }
            is Command.TypeText -> {
                val svc = MayaAccessibilityService.instance
                if (svc == null) needA11y()
                else if (svc.typeText(cmd.text)) m("लिख दिया.", "Typed it.")
                else m("लिखने की जगह नहीं मिली. पहले टेक्स्ट बॉक्स दबाओ.", "I couldn't find a text box. Tap one first.")
            }
            is Command.WebSearch -> when (actions.webSearch(cmd.query)) {
                PhoneActions.Outcome.OK -> m(
                    "${cmd.query} सर्च कर रही हूँ.", "Searching the web for ${cmd.query}."
                )
                else -> m("सर्च नहीं खुल पाया.", "Couldn't open the search.")
            }
            is Command.OpenWebsite -> when (actions.openWebsite(cmd.url)) {
                PhoneActions.Outcome.OK -> m("${cmd.url} खोल रही हूँ.", "Opening ${cmd.url}.")
                else -> m("वेबसाइट नहीं खुल पाई.", "Couldn't open the website.")
            }
            is Command.Flashlight -> when (actions.flashlight(cmd.on)) {
                PhoneActions.Outcome.OK ->
                    if (cmd.on) m("टॉर्च चालू कर दी.", "Flashlight on.") else m("टॉर्च बंद कर दी.", "Flashlight off.")
                else -> m("टॉर्च नहीं चल पाई.", "Couldn't control the flashlight.")
            }
            is Command.Volume -> when (actions.volume(cmd.action)) {
                PhoneActions.Outcome.OK -> when (cmd.action) {
                    VolumeAction.UP -> m("वॉल्यूम बढ़ा दिया.", "Volume up.")
                    VolumeAction.DOWN -> m("वॉल्यूम कम कर दिया.", "Volume down.")
                    VolumeAction.MUTE -> m("म्यूट कर दिया.", "Muted.")
                }
                else -> m("वॉल्यूम नहीं बदल पाई.", "Couldn't change the volume.")
            }
            Command.GoHome -> when (actions.goHome()) {
                PhoneActions.Outcome.OK -> m("होम स्क्रीन पर जा रही हूँ.", "Going to the home screen.")
                else -> m("होम पर नहीं जा पाई.", "Couldn't go home.")
            }
            Command.Time -> {
                val t = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
                m("अभी समय $t है.", "The time is $t.")
            }
            Command.Date -> {
                val d = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date())
                m("आज $d है.", "Today is $d.")
            }
            Command.Unsupported -> m(
                "फुलस्क्रीन जैसा कंट्रोल अभी सपोर्ट नहीं है.",
                "Fullscreen control isn't supported yet."
            )
            is Command.Media -> when (actions.mediaKey(cmd.action)) {
                PhoneActions.Outcome.OK -> m(
                    "मीडिया कमांड भेज दिया. ये तभी काम करेगा जब कोई प्लेयर चल रहा हो.",
                    "Sent the media command. It only works if a player is active."
                )
                else -> m("मीडिया कमांड नहीं भेज पाई.", "Couldn't send the media command.")
            }
            is Command.WhatsApp -> whatsappChat(cmd.name)
            is Command.Remember -> {
                if (memory.add(cmd.text)) {
                    m("ठीक है, याद रख लिया.", "Okay, I'll remember that.")
                } else {
                    m("मैं इसे हमेशा के लिए सेव नहीं कर पाई, सिर्फ अभी के लिए याद है.",
                        "I couldn't save that permanently; I only have it for now.")
                }
            }
            Command.ForgetAll -> {
                if (memory.clear()) m("सब भूल गई.", "Memory cleared.")
                else m("मेमोरी पूरी तरह साफ़ नहीं हो पाई.", "I couldn't fully clear the memory.")
            }
            is Command.Unclear -> if (cmd.what == "volume") {
                m("वॉल्यूम बढ़ाना है या कम करना है?", "Do you want the volume up or down?")
            } else {
                m("कौन सा ऐप खोलूँ?", "Which app should I open?")
            }
            is Command.Unknown -> ""
        }
    }

    private fun speak(raw: String) {
        val text = raw.replace("*", "").replace("#", "")
        reply = text
        val t = tts
        if (!ttsReady || t == null) {
            state = AssistantState.STANDBY
            scheduleRestart(800)
            return
        }
        val r = t.setLanguage(Locale.forLanguageTag(store.language))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            t.setLanguage(Locale.forLanguageTag("en-IN"))
            reply = text + "\n(Is bhasha ki voice phone mein nahi hai. Phone Settings > Text-to-speech mein install karo.)"
        }
        t.setPitch(store.pitch)
        t.setSpeechRate(store.speed)
        state = AssistantState.SPEAKING
        try { recognizer?.cancel() } catch (e: Exception) { }
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "maya")
    }
}
