package com.jarvisx.app.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvisx.app.data.ChatMsg

@Composable
fun HistoryScreen(
    p: JarvisPalette,
    history: List<ChatMsg>,
    memories: List<String>,
    onClearHistory: () -> Unit,
    onClearMemory: () -> Unit,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .padding(20.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("< BACK", color = p.accent2) }
            Text("HISTORY & MEMORY", color = p.accent, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))

        Text("Memory (jo tumne yaad rakhne ko kaha)", color = p.text, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        if (memories.isEmpty()) {
            Text("Abhi kuch nahi. Bolo: \"yaad rakho mera naam ...\"", color = p.subText, fontSize = 13.sp)
        } else {
            memories.forEach { Text("• $it", color = p.text, fontSize = 14.sp) }
            OutlinedButton(onClick = onClearMemory) { Text("Memory delete karo", color = p.accent2) }
        }

        Spacer(Modifier.height(20.dp))
        Text("Baat-cheet ki history", color = p.text, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        if (history.isEmpty()) {
            Text("Abhi khaali hai.", color = p.subText, fontSize = 13.sp)
        } else {
            history.forEach {
                val who = if (it.role == "user") "TUM" else "JARVIS"
                Text(
                    "$who: ${it.text}",
                    color = if (it.role == "user") p.text else p.accent2,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(vertical = 3.dp)
                )
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onClearHistory) { Text("History delete karo", color = p.accent2) }
        }
    }
}
