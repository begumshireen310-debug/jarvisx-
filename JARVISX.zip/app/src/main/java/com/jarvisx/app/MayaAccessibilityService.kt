package com.jarvisx.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.jarvisx.app.core.ScreenAction

/** Lets JARVIS press buttons / scroll / go back for you. Only acts when you give a voice command. */
class MayaAccessibilityService : AccessibilityService() {
    enum class PlayResult { CLICKED, TAPPED, NOT_READY }

    companion object {
        @Volatile var instance: MayaAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    fun doAction(a: ScreenAction): Boolean {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        return when (a) {
            ScreenAction.BACK -> performGlobalAction(GLOBAL_ACTION_BACK)
            ScreenAction.RECENTS -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            ScreenAction.NOTIFICATIONS -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            ScreenAction.QUICK -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
            ScreenAction.LOCK -> Build.VERSION.SDK_INT >= 28 && performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
            ScreenAction.SCREENSHOT -> Build.VERSION.SDK_INT >= 28 && performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
            ScreenAction.SCROLL_DOWN -> swipe(w / 2f, h * 0.70f, w / 2f, h * 0.30f)
            ScreenAction.SCROLL_UP -> swipe(w / 2f, h * 0.30f, w / 2f, h * 0.70f)
        }
    }

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float): Boolean {
        val p = Path()
        p.moveTo(x1, y1)
        p.lineTo(x2, y2)
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0L, 350L))
            .build()
        return dispatchGesture(g, null, null)
    }

    private fun tap(x: Float, y: Float): Boolean {
        val p = Path()
        p.moveTo(x, y)
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0L, 60L))
            .build()
        return dispatchGesture(g, null, null)
    }

    private fun clickNode(node: AccessibilityNodeInfo?): Boolean {
        var n = node
        var depth = 0
        while (n != null && depth < 8) {
            if (n.isClickable && n.isEnabled) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            n = n.parent
            depth++
        }
        return false
    }

    fun clickText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val list = root.findAccessibilityNodeInfosByText(text)
        for (n in list) {
            if (clickNode(n)) return true
        }
        return false
    }

    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        var target = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (target == null) target = findEditable(root)
        if (target == null) return false
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    private fun findEditable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isEditable) return n
        for (i in 0 until n.childCount) {
            val r = findEditable(n.getChild(i))
            if (r != null) return r
        }
        return null
    }

    private fun findByDesc(n: AccessibilityNodeInfo?, keys: List<String>): AccessibilityNodeInfo? {
        if (n == null) return null
        val d = n.contentDescription?.toString()?.lowercase()
        if (d != null && keys.any { d.contains(it) }) return n
        for (i in 0 until n.childCount) {
            val r = findByDesc(n.getChild(i), keys)
            if (r != null) return r
        }
        return null
    }

    /** Tries to press the first video in YouTube search results. Cannot confirm that playback started. */
    fun playFirstYouTubeResult(): PlayResult {
        val root = rootInActiveWindow ?: return PlayResult.NOT_READY
        if (root.packageName?.toString() != "com.google.android.youtube") return PlayResult.NOT_READY
        val hit = findByDesc(root, listOf("play video", "वीडियो चलाएं"))
        if (hit != null && clickNode(hit)) return PlayResult.CLICKED
        val dm = resources.displayMetrics
        return if (tap(dm.widthPixels / 2f, dm.heightPixels * 0.32f)) PlayResult.TAPPED else PlayResult.NOT_READY
    }
}
