package com.jarvisx.app.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.jarvisx.app.ai.GeminiClient
import com.jarvisx.app.core.AssistantController
import com.jarvisx.app.data.ApiKeyStore
import com.jarvisx.app.data.ChatLog
import com.jarvisx.app.data.MemoryStore
import com.jarvisx.app.data.SettingsStore
import kotlinx.coroutines.launch

private enum class Screen { HOME, SETTINGS, HISTORY }

@Composable
fun JarvisApp(store: SettingsStore, keyStore: ApiKeyStore) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    var theme by remember { mutableStateOf(store.theme) }
    var pitch by remember { mutableFloatStateOf(store.pitch) }
    var speed by remember { mutableFloatStateOf(store.speed) }
    var language by remember { mutableStateOf(store.language) }
    var screen by remember { mutableStateOf(Screen.HOME) }
    var hasKey by remember { mutableStateOf(keyStore.load().isNotEmpty()) }
    var keyMsg by remember { mutableStateOf("") }
    var testing by remember { mutableStateOf(false) }

    val memory = remember { MemoryStore(keyStore) }
    val chatLog = remember { ChatLog(keyStore) }
    val controller = remember { AssistantController(ctx, store, keyStore, memory, chatLog) }
    DisposableEffect(Unit) { onDispose { controller.shutdown() } }

    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            controller.onMicPressed()
        } else {
            controller.showMessage("Mic permission ke bina main sun nahi sakta.")
        }
    }

    val onMic: () -> Unit = {
        val ok = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (ok) controller.onMicPressed() else permLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    val p = paletteFor(theme)

    BackHandler(enabled = screen != Screen.HOME) { screen = Screen.HOME }

    JarvisTheme(p) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(p.bgTop, p.bgBottom)))
        ) {
            when (screen) {
                Screen.HOME -> HomeScreen(
                    p = p,
                    state = controller.state,
                    heard = controller.heard,
                    reply = controller.reply,
                    onMic = onMic,
                    onHistory = { screen = Screen.HISTORY },
                    onSettings = { screen = Screen.SETTINGS }
                )
                Screen.HISTORY -> HistoryScreen(
                    p = p,
                    history = chatLog.items,
                    memories = memory.items,
                    onClearHistory = { chatLog.clear() },
                    onClearMemory = { memory.clear() },
                    onBack = { screen = Screen.HOME }
                )
                Screen.SETTINGS -> SettingsScreen(
                    p = p, theme = theme, pitch = pitch, speed = speed, language = language,
                    hasKey = hasKey, keyMsg = keyMsg, testing = testing,
                    onTheme = { theme = it; store.theme = it },
                    onPitch = { pitch = it; store.pitch = it },
                    onSpeed = { speed = it; store.speed = it },
                    onPreset = { a, b ->
                        pitch = a; speed = b
                        store.pitch = a; store.speed = b
                    },
                    onLanguage = { language = it; store.language = it },
                    onSaveKey = { k ->
                        if (k.isBlank()) {
                            keyMsg = "Key khaali hai."
                        } else if (keyStore.save(k)) {
                            hasKey = true
                            keyMsg = "Key save ho gayi (encrypted)."
                        } else {
                            keyMsg = "Save nahi hui: is phone par secure storage nahi chala."
                        }
                    },
                    onTestKey = {
                        testing = true
                        keyMsg = "Test chal raha hai..."
                        scope.launch {
                            val r = GeminiClient.testKey(keyStore.load())
                            keyMsg = r.message
                            testing = false
                        }
                    },
                    onDeleteKey = {
                        if (keyStore.clear()) {
                            hasKey = false
                            keyMsg = "Key delete ho gayi."
                        } else {
                            keyMsg = "Delete nahi ho paayi."
                        }
                    },
                    onReset = {
                        store.clearAll()
                        theme = store.theme
                        pitch = store.pitch
                        speed = store.speed
                        language = store.language
                    },
                    onBack = { screen = Screen.HOME }
                )
            }
        }
    }
}
