package com.jarvisx.app.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.jarvisx.app.FloatingService
import com.jarvisx.app.VoiceService
import com.jarvisx.app.ai.GeminiClient
import com.jarvisx.app.core.Maya
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private enum class Screen { HOME, SETTINGS, HISTORY }

private fun isA11yEnabled(ctx: android.content.Context): Boolean {
    val s = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        ?: return false
    return s.contains(ctx.packageName)
}

@Composable
fun JarvisApp(listenTrigger: Int) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val controller = remember { Maya.get(ctx) }
    val store = controller.store
    val keyStore = controller.keyStore

    var theme by remember { mutableStateOf(store.theme) }
    var pitch by remember { mutableFloatStateOf(store.pitch) }
    var speed by remember { mutableFloatStateOf(store.speed) }
    var language by remember { mutableStateOf(store.language) }
    var screen by remember { mutableStateOf(Screen.HOME) }
    var hasKey by remember { mutableStateOf(keyStore.load().isNotEmpty()) }
    var keyMsg by remember { mutableStateOf("") }
    var testing by remember { mutableStateOf(false) }
    var orbMsg by remember { mutableStateOf("") }
    var userName by remember { mutableStateOf(store.userName) }
    var splash by remember { mutableStateOf(true) }
    var a11yTick by remember { mutableIntStateOf(0) }
    var orbOn by remember { mutableStateOf(false) }
    var bgMsg by remember { mutableStateOf("") }
    var pendingBg by remember { mutableStateOf(false) }
    var notifAsked by remember { mutableStateOf(false) }
    val bgStarter = remember { mutableStateOf<() -> Unit>({}) }

    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            if (pendingBg) {
                pendingBg = false
                bgStarter.value()
            } else {
                controller.onMicPressed()
            }
        } else {
            pendingBg = false
            controller.showMessage("Mic permission ke bina main sun nahi sakti.")
        }
    }
    val notifLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ -> bgStarter.value() }
    val contactsLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            controller.retryPendingContact()
        } else {
            controller.showMessage("Contacts permission ke bina naam dhundh nahi sakti.")
        }
    }

    val onMic: () -> Unit = {
        val ok = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (ok) controller.onMicPressed() else permLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    val startBg: () -> Unit = {
        val micOk = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (!micOk) {
            pendingBg = true
            permLauncher.launch(Manifest.permission.RECORD_AUDIO)
        } else if (Build.VERSION.SDK_INT >= 33 && !notifAsked &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            notifAsked = true
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, VoiceService::class.java))
                bgMsg = "Background listening chalu. Notification dikhna chahiye."
            } catch (e: Exception) {
                bgMsg = "Background listening start nahi ho paayi."
            }
        }
        Unit
    }
    bgStarter.value = startBg

    val stopBg: () -> Unit = {
        ctx.stopService(Intent(ctx, VoiceService::class.java))
        bgMsg = "Background listening band."
    }
    val toggleBg: () -> Unit = { if (controller.continuous) stopBg() else startBg() }

    val startOrb: () -> Unit = {
        if (!Settings.canDrawOverlays(ctx)) {
            orbMsg = "Pehle 'Display over other apps' ki ijazat do, phir wapas aakar Start dabao."
            ctx.startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName))
            )
        } else {
            try {
                ctx.startForegroundService(Intent(ctx, FloatingService::class.java))
                orbMsg = "Orb chalu. Dusre apps par dikhega; dabao to Maya sunegi."
                orbOn = true
            } catch (e: Exception) {
                orbMsg = "Orb start nahi ho paaya."
            }
        }
        Unit
    }
    val stopOrb: () -> Unit = {
        ctx.stopService(Intent(ctx, FloatingService::class.java))
        orbMsg = "Orb band."
        orbOn = false
    }

    val openBattery: () -> Unit = {
        try {
            ctx.startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + ctx.packageName))
            )
        } catch (e: Exception) {
            try {
                ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e2: Exception) {
                bgMsg = "Battery settings nahi khul paayi. Phone Settings > Battery mein dekho."
            }
        }
        Unit
    }

    val cycleVoice: () -> Unit = {
        val idx = if (pitch > 0.85f) 0 else if (pitch > 0.6f) 1 else 2
        val next = (idx + 1) % 3
        val a = if (next == 0) 1.0f else if (next == 1) 0.7f else 0.5f
        val b = if (next == 0) 1.0f else if (next == 1) 0.95f else 0.85f
        pitch = a; speed = b
        store.pitch = a; store.speed = b
    }
    val cycleLang: () -> Unit = {
        val next = if (language == "hi-IN") "en-IN" else if (language == "en-IN") "en-US" else "hi-IN"
        language = next
        store.language = next
    }

    LaunchedEffect(controller.needContacts) {
        if (controller.needContacts) {
            controller.clearNeedContacts()
            contactsLauncher.launch(Manifest.permission.READ_CONTACTS)
        }
    }
    LaunchedEffect(listenTrigger) {
        if (listenTrigger > 0) onMic()
    }

    LaunchedEffect(Unit) {
        delay(1800)
        splash = false
    }
    val a11yOn = remember(a11yTick, screen) { isA11yEnabled(ctx) }
    val openA11y: () -> Unit = {
        try {
            ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        } catch (e: Exception) {
            bgMsg = "Accessibility settings nahi khuli. Phone Settings mein dhundo."
        }
        Unit
    }

    val p = paletteFor(theme)
    BackHandler(enabled = screen != Screen.HOME) { screen = Screen.HOME }

    val voiceName = if (pitch > 0.85f) "NORMAL" else if (pitch > 0.6f) "DEEP" else "ROBOT"
    val langName = if (language == "hi-IN") "HI" else if (language == "en-IN") "EN-IN" else "EN-US"
    val nodes = listOf(
        HubNode("VOICE", voiceName, cycleVoice),
        HubNode("LANG", langName, cycleLang),
        HubNode("BG", if (controller.continuous) "ON" else "OFF", toggleBg),
        HubNode("ORB", if (orbOn) "ON" else "OFF", { if (orbOn) stopOrb() else startOrb() }),
        HubNode("LOG", "OPEN", { screen = Screen.HISTORY }),
        HubNode("SET", "OPEN", { screen = Screen.SETTINGS })
    )

    JarvisTheme(p) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(p.bgTop, p.bgBottom)))
        ) {
            if (splash) {
                SplashScreen(userName, p)
            } else when (screen) {
                Screen.HOME -> HomeScreen(
                    p = p,
                    state = controller.state,
                    heard = controller.heard,
                    reply = controller.reply,
                    bgOn = controller.continuous,
                    userName = userName,
                    screenCtl = a11yOn,
                    nodes = nodes,
                    onCore = onMic,
                    onHush = { controller.hush() }
                )
                Screen.HISTORY -> HistoryScreen(
                    p = p,
                    history = controller.chatLog.items,
                    memories = controller.memory.items,
                    onClearHistory = { controller.chatLog.clear() },
                    onClearMemory = { controller.memory.clear() },
                    onBack = { screen = Screen.HOME }
                )
                Screen.SETTINGS -> SettingsScreen(
                    p = p, theme = theme, pitch = pitch, speed = speed, language = language,
                    hasKey = hasKey, keyMsg = keyMsg, testing = testing, orbMsg = orbMsg,
                    userName = userName,
                    onUserName = { userName = it; store.userName = it },
                    a11yOn = a11yOn, onOpenA11y = openA11y, onCheckA11y = { a11yTick += 1 },
                    bgOn = controller.continuous, bgMsg = bgMsg,
                    onStartBg = startBg, onStopBg = stopBg, onBattery = openBattery,
                    onStartOrb = startOrb, onStopOrb = stopOrb,
                    onTheme = { theme = it; store.theme = it },
                    onPitch = { pitch = it; store.pitch = it },
                    onSpeed = { speed = it; store.speed = it },
                    onPreset = { a, b ->
                        pitch = a; speed = b
                        store.pitch = a; store.speed = b
                    },
                    onLanguage = { language = it; store.language = it },
                    onSaveKey = { k ->
                        if (k.isBlank()) {
                            keyMsg = "Key khaali hai."
                        } else if (keyStore.save(k)) {
                            hasKey = true
                            keyMsg = "Key save ho gayi (encrypted)."
                        } else {
                            keyMsg = "Save nahi hui: is phone par secure storage nahi chala."
                        }
                    },
                    onTestKey = {
                        testing = true
                        keyMsg = "Test chal raha hai..."
                        scope.launch {
                            val r = GeminiClient.testKey(keyStore.load())
                            keyMsg = r.message
                            testing = false
                        }
                    },
                    onDeleteKey = {
                        if (keyStore.clear()) {
                            hasKey = false
                            keyMsg = "Key delete ho gayi."
                        } else {
                            keyMsg = "Delete nahi ho paayi."
                        }
                    },
                    onReset = {
                        store.clearAll()
                        theme = store.theme
                        pitch = store.pitch
                        speed = store.speed
                        language = store.language
                        userName = store.userName
                    },
                    onBack = { screen = Screen.HOME }
                )
            }
        }
    }
}
