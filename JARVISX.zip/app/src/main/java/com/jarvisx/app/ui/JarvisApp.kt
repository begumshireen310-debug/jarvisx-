package com.jarvisx.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import com.jarvisx.app.data.SettingsStore

private enum class Screen { HOME, SETTINGS }

@Composable
fun JarvisApp(store: SettingsStore) {
    var theme by remember { mutableStateOf(store.theme) }
    var pitch by remember { mutableFloatStateOf(store.pitch) }
    var speed by remember { mutableFloatStateOf(store.speed) }
    var language by remember { mutableStateOf(store.language) }
    var screen by remember { mutableStateOf(Screen.HOME) }
    var state by remember { mutableStateOf(AssistantState.STANDBY) }

    val p = paletteFor(theme)

    BackHandler(enabled = screen == Screen.SETTINGS) { screen = Screen.HOME }

    JarvisTheme(p) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(p.bgTop, p.bgBottom)))
        ) {
            when (screen) {
                Screen.HOME -> HomeScreen(
                    p = p,
                    state = state,
                    onMic = {
                        // DEMO: cycles the visual states. Real microphone arrives in Batch 2.
                        state = when (state) {
                            AssistantState.STANDBY -> AssistantState.LISTENING
                            AssistantState.LISTENING -> AssistantState.PROCESSING
                            AssistantState.PROCESSING -> AssistantState.SPEAKING
                            AssistantState.SPEAKING -> AssistantState.STANDBY
                        }
                    },
                    onSettings = { screen = Screen.SETTINGS }
                )
                Screen.SETTINGS -> SettingsScreen(
                    p = p, theme = theme, pitch = pitch, speed = speed, language = language,
                    onTheme = { theme = it; store.theme = it },
                    onPitch = { pitch = it; store.pitch = it },
                    onSpeed = { speed = it; store.speed = it },
                    onLanguage = { language = it; store.language = it },
                    onReset = {
                        store.clearAll()
                        theme = store.theme; pitch = store.pitch
                        speed = store.speed; language = store.language
                    },
                    onBack = { screen = Screen.HOME }
                )
            }
        }
    }
}
