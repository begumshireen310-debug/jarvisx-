package com.jarvisx.app.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun LogoMark(accent: Color, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "logo")
    val spin by t.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing)),
        label = "logoSpin"
    )
    Canvas(modifier = modifier) {
        val c = center
        val r = size.minDimension / 2f
        drawCircle(color = accent.copy(alpha = 0.18f), radius = r, center = c)
        drawCircle(color = accent, radius = r - 2f, center = c, style = Stroke(width = 3f))
        rotate(spin, c) {
            for (k in 0 until 3) {
                drawArc(
                    color = accent,
                    startAngle = k * 120f + 10f,
                    sweepAngle = 70f,
                    useCenter = false,
                    topLeft = Offset(c.x - r * 0.7f, c.y - r * 0.7f),
                    size = Size(r * 1.4f, r * 1.4f),
                    style = Stroke(width = 5f, cap = StrokeCap.Round)
                )
            }
        }
        drawCircle(
            brush = Brush.radialGradient(listOf(Color.White, accent), center = c, radius = r * 0.35f),
            radius = r * 0.3f,
            center = c
        )
    }
}

@Composable
fun BrandRow(name: String, p: JarvisPalette, accent: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        LogoMark(accent, Modifier.size(40.dp))
        Spacer(Modifier.width(10.dp))
        Column {
            Text(name.uppercase(), color = accent, fontSize = 18.sp, fontWeight = FontWeight.Bold, letterSpacing = 5.sp)
            Text("JARVIS  //  A.I.", color = p.subText, fontSize = 10.sp, letterSpacing = 3.sp)
        }
    }
}

@Composable
fun SplashScreen(name: String, p: JarvisPalette) {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        LogoMark(p.accent, Modifier.size(140.dp))
        Spacer(Modifier.height(24.dp))
        Text(name.uppercase(), color = p.accent, fontSize = 30.sp, fontWeight = FontWeight.Bold, letterSpacing = 10.sp)
        Spacer(Modifier.height(6.dp))
        Text("JARVIS  A.I.  ASSISTANT", color = p.subText, fontSize = 12.sp, letterSpacing = 4.sp)
    }
}
