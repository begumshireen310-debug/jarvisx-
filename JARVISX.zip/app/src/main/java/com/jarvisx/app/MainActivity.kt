package com.jarvisx.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import com.jarvisx.app.data.ApiKeyStore
import com.jarvisx.app.data.SettingsStore
import com.jarvisx.app.ui.JarvisApp

class MainActivity : ComponentActivity() {
    private var listenTrigger by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = SettingsStore(applicationContext)
        val keyStore = ApiKeyStore(applicationContext)
        handleIntent(intent)
        setContent { JarvisApp(store, keyStore, listenTrigger) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i?.getBooleanExtra("listen", false) == true) {
            listenTrigger += 1
            i.removeExtra("listen")
        }
    }
}
