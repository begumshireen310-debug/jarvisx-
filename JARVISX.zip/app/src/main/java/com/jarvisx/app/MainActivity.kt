package com.jarvisx.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.jarvisx.app.data.ApiKeyStore
import com.jarvisx.app.data.SettingsStore
import com.jarvisx.app.ui.JarvisApp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = SettingsStore(applicationContext)
        val keyStore = ApiKeyStore(applicationContext)
        setContent { JarvisApp(store, keyStore) }
    }
}
