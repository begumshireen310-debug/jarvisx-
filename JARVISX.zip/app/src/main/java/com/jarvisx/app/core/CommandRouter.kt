package com.jarvisx.app.core

enum class KnownApp(val display: String, val pkg: String?, val aliases: List<String>) {
    YOUTUBE("YouTube", "com.google.android.youtube", listOf("youtube", "यूट्यूब", "utube")),
    CHROME("Chrome", "com.android.chrome", listOf("chrome", "क्रोम", "browser", "ब्राउज़र", "ब्राउजर")),
    CAMERA("Camera", null, listOf("camera", "कैमरा", "कैमेरा")),
    SETTINGS("Settings", null, listOf("settings", "setting", "सेटिंग", "सेटिंग्स", "सेटिंग्ज")),
    INSTAGRAM("Instagram", "com.instagram.android", listOf("instagram", "इंस्टाग्राम", "insta")),
    WHATSAPP("WhatsApp", "com.whatsapp", listOf("whatsapp", "व्हाट्सएप", "वाट्सएप", "व्हाट्सऐप", "व्हाट्सअप")),
    FACEBOOK("Facebook", "com.facebook.katana", listOf("facebook", "फेसबुक")),
    TELEGRAM("Telegram", "org.telegram.messenger", listOf("telegram", "टेलीग्राम")),
    SPOTIFY("Spotify", "com.spotify.music", listOf("spotify", "स्पॉटिफाई")),
    GMAIL("Gmail", "com.google.android.gm", listOf("gmail", "जीमेल")),
    MAPS("Maps", "com.google.android.apps.maps", listOf("maps", "map", "मैप्स", "मैप")),
    PLAYSTORE("Play Store", "com.android.vending", listOf("playstore", "प्लेस्टोर", "प्लेस्टोर"))
}

enum class VolumeAction { UP, DOWN, MUTE }

sealed class Command {
    data class OpenApp(val app: KnownApp) : Command()
    data class YouTubeSearch(val query: String) : Command()
    data class YouTubePlay(val query: String) : Command()
    data class WebSearch(val query: String) : Command()
    data class OpenWebsite(val url: String) : Command()
    data class Flashlight(val on: Boolean) : Command()
    data class Volume(val action: VolumeAction) : Command()
    object GoHome : Command()
    object Time : Command()
    object Date : Command()
    object Unsupported : Command()
    data class Unclear(val what: String) : Command()
    data class Unknown(val text: String) : Command()
}

object CommandRouter {
    private val wakeWords = listOf(
        "hey jarvis", "hello jarvis", "ok jarvis", "jarvis",
        "हे जार्विस", "हेलो जार्विस", "जार्विस", "जारविस", "जरविस", "जर्विस"
    )
    private val openWords = setOf("open", "launch", "start", "kholo", "khol", "kholna", "खोलो", "खोल", "खोलिए", "खोलना")
    private val searchWords = setOf(
        "search", "serch", "google", "dhundo", "dhoondo", "khojo", "dhundh",
        "सर्च", "खोजो", "ढूंढो", "ढूँढो", "खोज"
    )
    private val playWords = setOf("play", "chalao", "bajao", "chala", "baja", "चलाओ", "बजाओ", "प्ले", "चला", "बजा")
    private val filler = setOf(
        "on", "in", "for", "the", "a", "an", "me", "mein", "mai", "par", "pe", "per", "ko", "ka", "ki", "ke",
        "liye", "please", "pls", "kar", "karo", "do", "de", "to", "and", "about",
        "से", "में", "पर", "को", "का", "की", "के", "लिए", "करो", "कर", "दो", "प्लीज", "और", "पे"
    )
    private val flashWords = setOf("flashlight", "torch", "torchlight", "टॉर्च", "टार्च", "फ्लैशलाइट", "फ़्लैशलाइट")
    private val offWords = setOf("off", "band", "bujha", "bujhao", "disable", "बंद", "बन्द", "बुझा", "बुझाओ")
    private val volumeWords = setOf("volume", "वॉल्यूम", "वोल्यूम", "वॉल्युम")
    private val volUp = setOf("up", "increase", "badha", "badhao", "zyada", "jyada", "louder", "बढ़ा", "बढ़ाओ", "ज्यादा", "ज़्यादा")
    private val volDown = setOf("down", "decrease", "kam", "ghata", "ghatao", "lower", "कम", "घटा", "घटाओ")
    private val muteWords = setOf("mute", "silent", "म्यूट", "साइलेंट")
    private val timeWords = setOf("time", "samay", "baje", "समय", "टाइम", "बजे")
    private val dateWords = setOf("date", "tarikh", "तारीख", "तारिख")
    private val homeWords = setOf("home", "होम")
    private val mediaWords = setOf(
        "pause", "resume", "next", "previous", "fullscreen", "पॉज़", "पॉज", "अगला", "पिछला", "रिज्यूम"
    )
    private val domainRegex = Regex("^[a-z0-9-]+(\\.[a-z0-9-]+)*\\.[a-z]{2,}$")
    private val cleanRegex = Regex("[^\\p{L}\\p{M}\\p{N}.\\- ]")

    fun tokenize(raw: String): List<String> {
        var t = raw.lowercase().replace("play store", "playstore")
        for (w in wakeWords.sortedByDescending { it.length }) t = t.replace(w, " ")
        t = cleanRegex.replace(t, " ")
        return t.split(Regex("\\s+"))
            .map { it.trim('.', '-') }
            .filter { it.isNotEmpty() }
    }

    fun parse(raw: String): Command {
        val tokens = tokenize(raw)
        if (tokens.isEmpty()) return Command.Unknown(raw)

        fun has(set: Set<String>) = tokens.any { it in set }

        // YouTube
        if (has(KnownApp.YOUTUBE.aliases.toSet())) {
            val ytSet = KnownApp.YOUTUBE.aliases.toSet()
            val hasPlay = has(playWords)
            val q = tokens.filter {
                it !in ytSet && it !in playWords && it !in searchWords && it !in openWords && it !in filler
            }.joinToString(" ")
            return when {
                q.isEmpty() -> Command.OpenApp(KnownApp.YOUTUBE)
                hasPlay -> Command.YouTubePlay(q)
                else -> Command.YouTubeSearch(q)
            }
        }

        // Flashlight
        if (has(flashWords)) return Command.Flashlight(on = !has(offWords))

        // Mute / volume
        if (has(muteWords)) return Command.Volume(VolumeAction.MUTE)
        if (has(volumeWords)) {
            return when {
                has(volUp) -> Command.Volume(VolumeAction.UP)
                has(volDown) -> Command.Volume(VolumeAction.DOWN)
                has(offWords) -> Command.Volume(VolumeAction.MUTE)
                else -> Command.Unclear("volume")
            }
        }

        // Media controls are not supported yet
        if (has(mediaWords)) return Command.Unsupported

        // Time / date
        if (has(timeWords)) return Command.Time
        if (has(dateWords)) return Command.Date

        // Home
        if (has(homeWords)) return Command.GoHome

        // Web search
        if (has(searchWords)) {
            val q = tokens.filter { it !in searchWords && it !in openWords && it !in filler }.joinToString(" ")
            if (q.isNotEmpty()) return Command.WebSearch(q)
        }

        // Website
        val domain = tokens.firstOrNull { domainRegex.matches(it) }
        if (domain != null) return Command.OpenWebsite(domain)

        // Open app
        val hasOpen = has(openWords)
        val app = KnownApp.values().firstOrNull { a -> tokens.any { it in a.aliases } }
        if (app != null && (hasOpen || tokens.count { it !in filler } == 1)) return Command.OpenApp(app)
        if (hasOpen && "google" in tokens) return Command.OpenWebsite("google.com")
        if (hasOpen) return Command.Unclear("app")

        return Command.Unknown(raw)
    }
}
