package com.jarvisx.app.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun HomeScreen(
    p: JarvisPalette,
    state: AssistantState,
    heard: String,
    reply: String,
    onMic: () -> Unit,
    onHistory: () -> Unit,
    onSettings: () -> Unit
) {
    val heardShown = if (heard.isEmpty()) "—" else heard
    val micLabel = when (state) {
        AssistantState.STANDBY -> "MIC"
        AssistantState.LISTENING -> "DONE"
        AssistantState.PROCESSING -> "..."
        AssistantState.SPEAKING -> "TALK"
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "JARVIS X", color = p.accent, fontSize = 22.sp,
                fontWeight = FontWeight.Bold, letterSpacing = 4.sp
            )
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onHistory) { Text("HISTORY", color = p.accent2) }
            TextButton(onClick = onSettings) { Text("SETTINGS", color = p.accent2) }
        }

        Text("STATUS: ${state.label}", color = p.subText, fontSize = 13.sp, letterSpacing = 2.sp)

        Box(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            JarvisOrb(state, p, Modifier.fillMaxWidth(0.8f).aspectRatio(1f))
        }

        SoundWave(
            active = state == AssistantState.LISTENING || state == AssistantState.SPEAKING,
            color = p.accent
        )
        Spacer(Modifier.height(12.dp))

        Text("YOU: $heardShown", color = p.text, fontSize = 15.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(6.dp))
        Text("JARVIS: $reply", color = p.accent2, fontSize = 15.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(6.dp))
        Text(
            "Try: YouTube kholo • torch on karo • volume badhao • yaad rakho ... • ya kuch bhi poocho",
            color = p.subText, fontSize = 11.sp, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(12.dp))

        Button(
            onClick = onMic,
            shape = CircleShape,
            contentPadding = PaddingValues(0.dp),
            colors = ButtonDefaults.buttonColors(containerColor = p.accent),
            modifier = Modifier.size(76.dp)
        ) {
            Text(micLabel, color = if (p.isDark) Color.Black else Color.White, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(8.dp))
    }
}
