package com.jarvisx.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun HomeScreen(
    p: JarvisPalette,
    state: AssistantState,
    onMic: () -> Unit,
    onSettings: () -> Unit
) {
    // DEMO text only. Real recognized speech / AI replies arrive in Batch 2-3.
    val command = when (state) {
        AssistantState.STANDBY -> "—"
        else -> "Jarvis, open YouTube"
    }
    val response = when (state) {
        AssistantState.STANDBY -> "Standby. Mic button dabao."
        AssistantState.LISTENING -> "Sun raha hoon..."
        AssistantState.PROCESSING -> "Samajh raha hoon..."
        AssistantState.SPEAKING -> "YouTube khol raha hoon."
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "JARVIS X", color = p.accent, fontSize = 22.sp,
                fontWeight = FontWeight.Bold, letterSpacing = 4.sp
            )
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onSettings) { Text("SETTINGS", color = p.accent2) }
        }

        Text(
            "STATUS: ${state.label}", color = p.subText, fontSize = 13.sp, letterSpacing = 2.sp
        )

        Box(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            JarvisOrb(state, p, Modifier.fillMaxWidth(0.85f).aspectRatio(1f))
        }

        SoundWave(
            active = state == AssistantState.LISTENING || state == AssistantState.SPEAKING,
            color = p.accent
        )
        Spacer(Modifier.height(16.dp))

        Text("YOU: $command", color = p.text, fontSize = 15.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(6.dp))
        Text("JARVIS: $response", color = p.accent2, fontSize = 15.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(6.dp))
        Text(
            "(DEMO — asli voice agle batch mein)", color = p.subText, fontSize = 11.sp
        )
        Spacer(Modifier.height(16.dp))

        Button(
            onClick = onMic,
            shape = CircleShape,
            contentPadding = PaddingValues(0.dp),
            colors = ButtonDefaults.buttonColors(containerColor = p.accent),
            modifier = Modifier.size(76.dp)
        ) {
            Text("MIC", color = if (p.isDark) Color.Black else Color.White, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(8.dp))
    }
}
