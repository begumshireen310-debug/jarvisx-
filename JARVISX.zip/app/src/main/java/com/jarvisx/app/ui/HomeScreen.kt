package com.jarvisx.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class HubNode(val label: String, val sub: String, val onClick: () -> Unit)

@Composable
fun HomeScreen(
    p: JarvisPalette,
    state: AssistantState,
    heard: String,
    reply: String,
    bgOn: Boolean,
    userName: String,
    screenCtl: Boolean,
    nodes: List<HubNode>,
    onCore: () -> Unit,
    onHush: () -> Unit
) {
    val accent = stateAccent(state, p)
    val heardShown = if (heard.isEmpty()) "—" else heard

    Column(
        modifier = Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            BrandRow(userName, p, accent)
            Spacer(Modifier.weight(1f))
            Text(
                "${state.label}  |  BG ${if (bgOn) "ON" else "OFF"}  |  SCREEN ${if (screenCtl) "ON" else "OFF"}",
                color = p.subText, fontSize = 11.sp, letterSpacing = 1.sp
            )
        }

        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
        ) {
            val s = maxWidth
            JarvisOrb(state, p, Modifier.fillMaxSize())
            Box(
                Modifier
                    .align(androidx.compose.ui.Alignment.Center)
                    .size(s * 0.36f)
                    .clip(CircleShape)
                    .pointerInput(Unit) {
                        detectTapGestures(onTap = { onCore() }, onLongPress = { onHush() })
                    }
            )
            nodes.forEachIndexed { i, n ->
                val a = Math.toRadians(-90.0 + i * 60.0)
                val rr = s.value * 0.40
                Box(
                    Modifier
                        .align(androidx.compose.ui.Alignment.Center)
                        .offset(x = (rr * Math.cos(a)).dp, y = (rr * Math.sin(a)).dp)
                ) {
                    NodeButton(n, p, accent)
                }
            }
        }

        Spacer(Modifier.height(6.dp))
        SoundWave(
            active = state == AssistantState.LISTENING || state == AssistantState.SPEAKING,
            color = accent
        )
        Spacer(Modifier.height(10.dp))

        Column(
            Modifier
                .fillMaxWidth()
                .border(1.dp, accent, RoundedCornerShape(4.dp))
                .background(p.bgTop.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
                .padding(12.dp)
        ) {
            Text("YOU: $heardShown", color = p.text, fontSize = 14.sp)
            Spacer(Modifier.height(6.dp))
            Text("JARVIS: $reply", color = accent, fontSize = 14.sp)
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "v0.7  |  Tap core: listen  |  Hold core: silence  |  BG: say Jarvis first",
            color = p.subText, fontSize = 11.sp, textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun NodeButton(n: HubNode, p: JarvisPalette, accent: Color) {
    Box(
        modifier = Modifier
            .size(54.dp)
            .clip(CircleShape)
            .background(p.bgTop.copy(alpha = 0.9f))
            .border(2.dp, accent, CircleShape)
            .clickable(onClick = n.onClick),
        contentAlignment = androidx.compose.ui.Alignment.Center
    ) {
        Column(horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
            Text(n.label, color = p.text, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text(n.sub, color = accent, fontSize = 8.sp)
        }
    }
}
