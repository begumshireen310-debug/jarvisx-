package com.jarvisx.app.core

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.ContactsContract
import android.provider.MediaStore
import android.view.KeyEvent
import android.provider.Settings

class PhoneActions(private val ctx: Context) {
    enum class Outcome { OK, NOT_INSTALLED, FAILED }

    private fun launch(intent: Intent): Outcome {
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
            Outcome.OK
        } catch (e: ActivityNotFoundException) {
            Outcome.NOT_INSTALLED
        } catch (e: Exception) {
            Outcome.FAILED
        }
    }

    fun openApp(app: KnownApp): Outcome {
        return when (app) {
            KnownApp.CAMERA -> launch(Intent(MediaStore.ACTION_IMAGE_CAPTURE))
            KnownApp.SETTINGS -> launch(Intent(Settings.ACTION_SETTINGS))
            else -> {
                val pkg = app.pkg
                val i = if (pkg == null) null else ctx.packageManager.getLaunchIntentForPackage(pkg)
                if (i == null) Outcome.NOT_INSTALLED else launch(i)
            }
        }
    }

    fun youtubeSearch(query: String): Outcome {
        val uri = Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query))
        val inApp = Intent(Intent.ACTION_VIEW, uri).setPackage("com.google.android.youtube")
        val r = launch(inApp)
        return if (r == Outcome.OK) r else launch(Intent(Intent.ACTION_VIEW, uri))
    }

    fun webSearch(query: String): Outcome {
        val uri = Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))
        return launch(Intent(Intent.ACTION_VIEW, uri))
    }

    fun openWebsite(url: String): Outcome {
        val full = if (url.startsWith("http")) url else "https://$url"
        return launch(Intent(Intent.ACTION_VIEW, Uri.parse(full)))
    }

    fun flashlight(on: Boolean): Outcome {
        return try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (id == null) {
                Outcome.FAILED
            } else {
                cm.setTorchMode(id, on)
                Outcome.OK
            }
        } catch (e: Exception) {
            Outcome.FAILED
        }
    }

    fun volume(action: VolumeAction): Outcome {
        return try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val dir = when (action) {
                VolumeAction.UP -> AudioManager.ADJUST_RAISE
                VolumeAction.DOWN -> AudioManager.ADJUST_LOWER
                VolumeAction.MUTE -> AudioManager.ADJUST_MUTE
            }
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
            Outcome.OK
        } catch (e: Exception) {
            Outcome.FAILED
        }
    }

    fun goHome(): Outcome {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        return launch(i)
    }

    fun mediaKey(action: MediaAction): Outcome {
        return try {
            val code = when (action) {
                MediaAction.PAUSE -> KeyEvent.KEYCODE_MEDIA_PAUSE
                MediaAction.PLAY -> KeyEvent.KEYCODE_MEDIA_PLAY
                MediaAction.NEXT -> KeyEvent.KEYCODE_MEDIA_NEXT
                MediaAction.PREV -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
                MediaAction.STOP -> KeyEvent.KEYCODE_MEDIA_STOP
            }
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
            Outcome.OK
        } catch (e: Exception) {
            Outcome.FAILED
        }
    }

    /** Needs READ_CONTACTS permission. Returns digits only, or null if not found. */
    fun findContactNumber(name: String): String? {
        return try {
            val cursor = ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
                arrayOf("%" + name + "%"),
                null
            )
            var result: String? = null
            cursor?.use {
                if (it.moveToFirst()) result = it.getString(0)
            }
            val digits = result?.filter { c -> c.isDigit() }
            if (digits.isNullOrEmpty()) null else if (digits.length == 10) "91$digits" else digits
        } catch (e: Exception) {
            null
        }
    }

    fun openWhatsAppChat(number: String): Outcome {
        val uri = Uri.parse("https://wa.me/$number")
        val r = launch(Intent(Intent.ACTION_VIEW, uri).setPackage("com.whatsapp"))
        return r
    }
}
