package com.jarvisx.app.data

import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject

data class ChatMsg(val role: String, val text: String)

/** Conversation history, kept encrypted on this phone. Separate from long-term memory. */
class ChatLog(private val store: ApiKeyStore) {
    val items = mutableStateListOf<ChatMsg>()

    init {
        try {
            val raw = store.getString("history").ifEmpty { "[]" }
            val a = JSONArray(raw)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                items.add(ChatMsg(o.getString("r"), o.getString("t")))
            }
        } catch (e: Exception) {
            // start empty
        }
    }

    fun add(role: String, text: String) {
        items.add(ChatMsg(role, text))
        while (items.size > 60) items.removeAt(0)
        save()
    }

    fun removeLast() {
        if (items.isNotEmpty()) {
            items.removeAt(items.size - 1)
            save()
        }
    }

    fun clear() {
        items.clear()
        save()
    }

    private fun save() {
        val a = JSONArray()
        items.forEach { a.put(JSONObject().put("r", it.role).put("t", it.text)) }
        store.putString("history", a.toString())
    }
}
