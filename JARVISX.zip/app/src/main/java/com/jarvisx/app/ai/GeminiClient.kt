package com.jarvisx.app.ai

import com.jarvisx.app.data.ChatMsg
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** For chat: ok=true -> message is the reply. ok=false -> message is an error to show. */
data class TestResult(val ok: Boolean, val message: String)

object GeminiClient {
    private val models = listOf("gemini-flash-latest", "gemini-2.5-flash")

    suspend fun testKey(key: String): TestResult = withContext(Dispatchers.IO) {
        if (key.isBlank()) return@withContext TestResult(false, "Key set nahi hai.")
        var conn: HttpURLConnection? = null
        try {
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models?pageSize=1")
            conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "GET"
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.setRequestProperty("x-goog-api-key", key)
            when (val code = conn.responseCode) {
                200 -> TestResult(true, "Key sahi hai. Google ne accept ki.")
                400, 401, 403 -> TestResult(false, "Key galat ya band hai (code $code). Dobara check karo.")
                429 -> TestResult(false, "Limit khatam (code 429). Thodi der baad try karo.")
                else -> TestResult(false, "Kuch gadbad (code $code).")
            }
        } catch (e: IOException) {
            TestResult(false, "Internet / network error. Net chalu hai?")
        } catch (e: Exception) {
            TestResult(false, "Test fail ho gaya.")
        } finally {
            conn?.disconnect()
        }
    }

    suspend fun chat(key: String, system: String, history: List<ChatMsg>): TestResult =
        withContext(Dispatchers.IO) {
            val body = JSONObject()
            body.put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system)))
            )
            val contents = JSONArray()
            history.forEach {
                contents.put(
                    JSONObject().put("role", it.role)
                        .put("parts", JSONArray().put(JSONObject().put("text", it.text)))
                )
            }
            body.put("contents", contents)
            body.put("generationConfig", JSONObject().put("maxOutputTokens", 400))

            var last = TestResult(false, "Kuch gadbad ho gayi.")
            for (m in models) {
                var conn: HttpURLConnection? = null
                try {
                    val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent")
                    conn = url.openConnection() as HttpURLConnection
                    conn.requestMethod = "POST"
                    conn.connectTimeout = 15000
                    conn.readTimeout = 25000
                    conn.doOutput = true
                    conn.setRequestProperty("Content-Type", "application/json")
                    conn.setRequestProperty("x-goog-api-key", key)
                    conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                    val code = conn.responseCode
                    if (code == 200) {
                        val txt = conn.inputStream.bufferedReader().use { it.readText() }
                        val reply = JSONObject(txt)
                            .getJSONArray("candidates").getJSONObject(0)
                            .getJSONObject("content").getJSONArray("parts")
                            .getJSONObject(0).getString("text")
                        return@withContext TestResult(true, reply.trim())
                    }
                    last = when (code) {
                        400, 401, 403 -> TestResult(false, "Key galat hai ya permission nahi (code $code). Settings mein check karo.")
                        429 -> TestResult(false, "Gemini ki limit khatam (code 429). Thodi der baad try karo.")
                        404 -> TestResult(false, "Gemini model nahi mila (code 404).")
                        else -> TestResult(false, "Gemini error (code $code).")
                    }
                    if (code != 404) return@withContext last
                } catch (e: IOException) {
                    return@withContext TestResult(false, "Internet / network error. Net check karo.")
                } catch (e: Exception) {
                    return@withContext TestResult(false, "Jawab padhne mein dikkat aayi. Dobara try karo.")
                } finally {
                    conn?.disconnect()
                }
            }
            last
        }
}
