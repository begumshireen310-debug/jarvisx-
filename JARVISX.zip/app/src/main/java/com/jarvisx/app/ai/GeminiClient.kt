package com.jarvisx.app.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

data class TestResult(val ok: Boolean, val message: String)

object GeminiClient {
    /** Only checks whether the key is accepted by Google. Real chat replies come in Batch 3. */
    suspend fun testKey(key: String): TestResult = withContext(Dispatchers.IO) {
        if (key.isBlank()) return@withContext TestResult(false, "Key set nahi hai.")
        var conn: HttpURLConnection? = null
        try {
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models?pageSize=1")
            conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "GET"
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.setRequestProperty("x-goog-api-key", key)
            when (val code = conn.responseCode) {
                200 -> TestResult(true, "Key sahi hai. Google ne accept ki.")
                400, 401, 403 -> TestResult(false, "Key galat ya band hai (code $code). Dobara check karo.")
                429 -> TestResult(false, "Limit khatam (code 429). Thodi der baad try karo.")
                else -> TestResult(false, "Kuch gadbad (code $code).")
            }
        } catch (e: IOException) {
            TestResult(false, "Internet / network error. Net chalu hai?")
        } catch (e: Exception) {
            TestResult(false, "Test fail ho gaya.")
        } finally {
            conn?.disconnect()
        }
    }
}
