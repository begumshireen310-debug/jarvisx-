package com.jarvisx.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingsScreen(
    p: JarvisPalette,
    theme: ThemeMode,
    pitch: Float,
    speed: Float,
    language: String,
    onTheme: (ThemeMode) -> Unit,
    onPitch: (Float) -> Unit,
    onSpeed: (Float) -> Unit,
    onLanguage: (String) -> Unit,
    onReset: () -> Unit,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .padding(20.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("< BACK", color = p.accent2) }
            Text("SETTINGS", color = p.accent, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))

        Section("Theme", p)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ThemeMode.values().forEach { m ->
                Choice(m.label, m == theme) { onTheme(m) }
            }
        }

        Spacer(Modifier.height(20.dp))
        Section("Language", p)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Choice("Hindi", language == "hi-IN") { onLanguage("hi-IN") }
            Choice("English", language == "en-US") { onLanguage("en-US") }
            Choice("Hinglish", language == "en-IN") { onLanguage("en-IN") }
        }

        Spacer(Modifier.height(20.dp))
        Section("Voice pitch: ${"%.2f".format(pitch)}", p)
        Slider(value = pitch, onValueChange = onPitch, valueRange = 0.5f..1.5f)
        Section("Voice speed: ${"%.2f".format(speed)}", p)
        Slider(value = speed, onValueChange = onSpeed, valueRange = 0.5f..1.5f)
        Text(
            "Ye values save ho jaati hain. Asli awaaz par asar agle batch (TTS) se.",
            color = p.subText, fontSize = 12.sp
        )

        Spacer(Modifier.height(28.dp))
        OutlinedButton(onClick = onReset) { Text("Reset settings", color = p.accent2) }
    }
}

@Composable
private fun Section(title: String, p: JarvisPalette) {
    Text(title, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    Spacer(Modifier.height(6.dp))
}

@Composable
private fun Choice(label: String, selected: Boolean, onClick: () -> Unit) {
    if (selected) {
        Button(onClick = onClick) { Text(label) }
    } else {
        OutlinedButton(onClick = onClick) { Text(label) }
    }
}
