package com.jarvisx.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingsScreen(
    p: JarvisPalette,
    theme: ThemeMode,
    pitch: Float,
    speed: Float,
    language: String,
    hasKey: Boolean,
    keyMsg: String,
    testing: Boolean,
    onTheme: (ThemeMode) -> Unit,
    onPitch: (Float) -> Unit,
    onSpeed: (Float) -> Unit,
    onPreset: (Float, Float) -> Unit,
    onLanguage: (String) -> Unit,
    onSaveKey: (String) -> Unit,
    onTestKey: () -> Unit,
    onDeleteKey: () -> Unit,
    onReset: () -> Unit,
    onBack: () -> Unit
) {
    var keyInput by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .padding(20.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("< BACK", color = p.accent2) }
            Text("SETTINGS", color = p.accent, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))

        Section("Gemini API key", p)
        OutlinedTextField(
            value = keyInput,
            onValueChange = { keyInput = it },
            label = { Text("Yahan key paste karo", color = p.subText) },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            textStyle = TextStyle(color = p.text),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                onSaveKey(keyInput)
                keyInput = ""
            }) { Text("Save") }
            OutlinedButton(onClick = onTestKey, enabled = hasKey && !testing) { Text("Test") }
            OutlinedButton(onClick = onDeleteKey, enabled = hasKey) { Text("Delete") }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            if (hasKey) "Key status: saved" else "Key status: not set",
            color = p.text, fontSize = 13.sp
        )
        if (keyMsg.isNotEmpty()) {
            Text(keyMsg, color = p.accent2, fontSize = 13.sp)
        }
        Text(
            "Key sirf is phone par encrypted save hoti hai. Kisi ko mat dena. " +
                "Key daalne ke baad jo command samajh na aaye, wo Gemini AI se poochha jaata hai.",
            color = p.subText, fontSize = 12.sp
        )

        Spacer(Modifier.height(20.dp))
        Section("Theme", p)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ThemeMode.values().forEach { m ->
                Choice(m.label, m == theme) { onTheme(m) }
            }
        }

        Spacer(Modifier.height(20.dp))
        Section("Language (sunne aur bolne ki)", p)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Choice("Hindi", language == "hi-IN") { onLanguage("hi-IN") }
            Choice("English", language == "en-US") { onLanguage("en-US") }
            Choice("Hinglish", language == "en-IN") { onLanguage("en-IN") }
        }

        Spacer(Modifier.height(20.dp))
        Section("Voice style", p)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { onPreset(1.0f, 1.0f) }) { Text("Normal") }
            OutlinedButton(onClick = { onPreset(0.7f, 0.95f) }) { Text("Deep") }
            OutlinedButton(onClick = { onPreset(0.5f, 0.85f) }) { Text("Robot") }
        }
        Text(
            "Robot = sabse bhaari aur dheemi awaaz. Asli metallic Iron-Man effect Android ki " +
                "awaaz engine se nahi aata; yahan sirf pitch/speed badalti hai.",
            color = p.subText, fontSize = 12.sp
        )
        Spacer(Modifier.height(12.dp))
        Section("Voice pitch: ${"%.2f".format(pitch)}", p)
        Slider(value = pitch, onValueChange = onPitch, valueRange = 0.5f..1.5f)
        Section("Voice speed: ${"%.2f".format(speed)}", p)
        Slider(value = speed, onValueChange = onSpeed, valueRange = 0.5f..1.5f)

        Spacer(Modifier.height(28.dp))
        OutlinedButton(onClick = onReset) { Text("Reset settings", color = p.accent2) }
    }
}

@Composable
private fun Section(title: String, p: JarvisPalette) {
    Text(title, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    Spacer(Modifier.height(6.dp))
}

@Composable
private fun Choice(label: String, selected: Boolean, onClick: () -> Unit) {
    if (selected) {
        Button(onClick = onClick) { Text(label) }
    } else {
        OutlinedButton(onClick = onClick) { Text(label) }
    }
}
