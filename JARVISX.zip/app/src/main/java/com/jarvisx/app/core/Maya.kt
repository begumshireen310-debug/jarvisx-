package com.jarvisx.app.core

import android.content.Context
import com.jarvisx.app.data.ApiKeyStore
import com.jarvisx.app.data.ChatLog
import com.jarvisx.app.data.MemoryStore
import com.jarvisx.app.data.SettingsStore

/** One shared assistant for the screen AND the background service. */
object Maya {
    @Volatile private var inst: AssistantController? = null

    fun get(ctx: Context): AssistantController {
        val cur = inst
        if (cur != null) return cur
        return synchronized(this) {
            val again = inst
            if (again != null) {
                again
            } else {
                val app = ctx.applicationContext
                val store = SettingsStore(app)
                val keys = ApiKeyStore(app)
                val c = AssistantController(app, store, keys, MemoryStore(keys), ChatLog(keys))
                inst = c
                c
            }
        }
    }
}
