package com.jarvisx.app.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp

fun stateAccent(state: AssistantState, p: JarvisPalette): Color = when (state) {
    AssistantState.STANDBY -> p.accent
    AssistantState.LISTENING -> Color(0xFF35FFB0)
    AssistantState.PROCESSING -> Color(0xFFFFB02E)
    AssistantState.SPEAKING -> Color(0xFFFF4D8D)
}

@Composable
fun JarvisOrb(state: AssistantState, p: JarvisPalette, modifier: Modifier = Modifier) {
    val period = when (state) {
        AssistantState.STANDBY -> 3200
        AssistantState.LISTENING -> 1200
        AssistantState.PROCESSING -> 700
        AssistantState.SPEAKING -> 900
    }
    val accent = stateAccent(state, p)
    val t = rememberInfiniteTransition(label = "orb")
    val pulse by t.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(tween(period, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    val spin by t.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(period * 5, easing = LinearEasing)),
        label = "spin"
    )

    Canvas(modifier = modifier) {
        val c = center
        val r = size.minDimension / 2f

        // outer glow
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(accent.copy(alpha = 0.45f), Color.Transparent),
                center = c, radius = r
            ),
            radius = r * pulse, center = c
        )
        // core
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color.White.copy(alpha = 0.95f), accent, accent.copy(alpha = 0.25f)),
                center = c, radius = r * 0.5f
            ),
            radius = r * 0.42f * pulse, center = c
        )
        // HUD ring 1 (clockwise)
        rotate(spin, c) {
            val d = r * 1.5f
            for (k in 0 until 3) {
                drawArc(
                    color = accent, startAngle = k * 120f, sweepAngle = 70f, useCenter = false,
                    topLeft = Offset(c.x - d / 2, c.y - d / 2), size = Size(d, d),
                    style = Stroke(width = 5f, cap = StrokeCap.Round)
                )
            }
        }
        // HUD ring 2 (counter-clockwise)
        rotate(-spin * 1.5f, c) {
            val d = r * 1.2f
            for (k in 0 until 4) {
                drawArc(
                    color = p.accent2.copy(alpha = 0.8f), startAngle = k * 90f, sweepAngle = 35f,
                    useCenter = false,
                    topLeft = Offset(c.x - d / 2, c.y - d / 2), size = Size(d, d),
                    style = Stroke(width = 3f, cap = StrokeCap.Round)
                )
            }
        }
        // tick ring (slow rotation)
        rotate(spin * 0.2f, c) {
            for (k in 0 until 72) {
                val ang = Math.toRadians(k * 5.0)
                val long = k % 6 == 0
                val r1 = r * (if (long) 0.90f else 0.93f)
                val r2 = r * 0.97f
                drawLine(
                    color = accent.copy(alpha = if (long) 0.9f else 0.4f),
                    start = Offset(c.x + (r1 * Math.cos(ang)).toFloat(), c.y + (r1 * Math.sin(ang)).toFloat()),
                    end = Offset(c.x + (r2 * Math.cos(ang)).toFloat(), c.y + (r2 * Math.sin(ang)).toFloat()),
                    strokeWidth = if (long) 3f else 1.5f
                )
            }
        }
        // thin static ring
        drawCircle(color = accent.copy(alpha = 0.35f), radius = r * 0.95f, center = c, style = Stroke(width = 2f))
    }
}

@Composable
fun SoundWave(active: Boolean, color: Color, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "wave")
    Row(
        modifier = modifier.height(48.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        repeat(15) { i ->
            val h by t.animateFloat(
                initialValue = 0.15f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    tween(380 + (i * 53) % 340, easing = LinearEasing), RepeatMode.Reverse
                ),
                label = "bar$i"
            )
            val frac = if (active) h else 0.08f
            Box(
                Modifier
                    .width(4.dp)
                    .fillMaxHeight(frac)
                    .background(color, RoundedCornerShape(2.dp))
            )
        }
    }
}
