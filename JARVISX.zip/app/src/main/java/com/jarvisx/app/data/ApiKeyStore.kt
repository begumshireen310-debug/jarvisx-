package com.jarvisx.app.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** Stores the user's Gemini API key encrypted on this phone only. Never logged, never in source code. */
class ApiKeyStore(context: Context) {
    private val prefs: SharedPreferences? = try {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            "jarvis_secure",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        null
    }

    fun save(key: String): Boolean {
        val p = prefs ?: return false
        return p.edit().putString("gemini_key", key.trim()).commit()
    }

    fun load(): String = prefs?.getString("gemini_key", "") ?: ""

    fun clear(): Boolean {
        val p = prefs ?: return false
        return p.edit().remove("gemini_key").commit()
    }

    fun putString(k: String, v: String): Boolean {
        val p = prefs ?: return false
        return p.edit().putString(k, v).commit()
    }

    fun getString(k: String): String = prefs?.getString(k, "") ?: ""
}
