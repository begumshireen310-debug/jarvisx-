package com.jarvisx.app

import com.jarvisx.app.core.Command
import com.jarvisx.app.core.CommandRouter
import com.jarvisx.app.core.KnownApp
import com.jarvisx.app.core.VolumeAction
import org.junit.Assert.assertEquals
import org.junit.Test

class CommandRouterTest {
    @Test fun openYoutube() {
        assertEquals(Command.OpenApp(KnownApp.YOUTUBE), CommandRouter.parse("Hey Jarvis open YouTube"))
    }
    @Test fun searchYoutube() {
        assertEquals(
            Command.YouTubeSearch("gta 5 gameplay"),
            CommandRouter.parse("Jarvis, search YouTube for GTA 5 gameplay")
        )
    }
    @Test fun playYoutube() {
        assertEquals(
            Command.YouTubePlay("relaxing music"),
            CommandRouter.parse("play relaxing music on youtube")
        )
    }
    @Test fun torchOnAndOff() {
        assertEquals(Command.Flashlight(true), CommandRouter.parse("torch on karo"))
        assertEquals(Command.Flashlight(false), CommandRouter.parse("torch band karo"))
    }
    @Test fun volume() {
        assertEquals(Command.Volume(VolumeAction.UP), CommandRouter.parse("volume badhao"))
        assertEquals(Command.Volume(VolumeAction.DOWN), CommandRouter.parse("volume kam karo"))
    }
    @Test fun hindiYoutube() {
        assertEquals(Command.OpenApp(KnownApp.YOUTUBE), CommandRouter.parse("जार्विस यूट्यूब खोलो"))
    }
    @Test fun webSearch() {
        assertEquals(Command.WebSearch("weather today"), CommandRouter.parse("search weather today"))
    }
    @Test fun unknown() {
        assertEquals(Command.Unknown("blah blah"), CommandRouter.parse("blah blah"))
    }
    @Test fun remember() {
        assertEquals(Command.Remember("mera naam Suleman hai"), CommandRouter.parse("Jarvis yaad rakho mera naam Suleman hai"))
    }
    @Test fun forget() {
        assertEquals(Command.ForgetAll, CommandRouter.parse("sab bhool jao"))
    }
}
